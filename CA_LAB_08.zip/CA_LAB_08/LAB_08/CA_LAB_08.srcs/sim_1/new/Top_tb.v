`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 01:20:43
// Design Name: 
// Module Name: Top_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module MemoryMappedSystem_tb;
    reg clk;
    reg rst;
    reg [31:0] address;
    reg [31:0] writeData;
    reg readEnable;
    reg writeEnable;
    reg [15:0] switches;

    wire [31:0] readData;
    wire [15:0] leds;

    // Instantiate Top Module
    addressDecoderTop dut (
        .clk(clk),
        .rst(rst),
        .address(address),
        .readEnable(readEnable),
        .writeEnable(writeEnable),
        .writeData(writeData),
        .switches(switches),
        .readData(readData),
        .leds(leds)
    );

    // 10ns clock period (100 MHz)
    always #5 clk = ~clk;

  initial begin
            // Reset
            clk         = 1'b0;
            rst         = 1'b1;
            readEnable  = 1'b0;
            writeEnable = 1'b0;
            address     = 32'b0;
            writeData   = 32'b0;
            switches    = 16'h0000;
    
            #20;
            rst = 1'b0;

                    // 1. DATA MEMORY WRITE (address[9:8] = 2'b00)
                    // ---------------------------------------------------------
                    @(negedge clk);
                    address     = 32'd4;             // address[9:8] == 2'b00
                    writeData   = 32'hAABBCCDD;
                    writeEnable = 1'b1;
                    readEnable  = 1'b0;
            
                    // ---------------------------------------------------------
                    // 2. DATA MEMORY READ (address[9:8] = 2'b00)
                    // ---------------------------------------------------------
                    @(negedge clk);
                    writeEnable = 1'b0;
                    readEnable  = 1'b1;
                    address     = 32'd4;             // address[9:8] == 2'b00
            
                    // ---------------------------------------------------------
                    // 3. LED WRITE (address[9:8] = 2'b01 -> use 256)
                    // ---------------------------------------------------------
                    @(negedge clk);
                    readEnable  = 1'b0;
                    address     = 32'd256;           // 256 = 10'b01_00000000 -> address[9:8] == 2'b01
                    writeData   = 32'h000055AA;
                    writeEnable = 1'b1;
            
                    // ---------------------------------------------------------
                    // 4. SWITCH READ (address[9:8] = 2'b10 -> use 512)
                    // ---------------------------------------------------------
                    @(negedge clk);
                    writeEnable = 1'b0;
                    address     = 32'd512;           // 512 = 10'b10_00000000 -> address[9:8] == 2'b10
                    switches    = 16'h1234;
                    readEnable  = 1'b1;
            
                    // ---------------------------------------------------------
                    // 5. UNUSED RANGE (address[9:8] = 2'b11 -> use 768)
                    // ---------------------------------------------------------
                    @(negedge clk);
                    address     = 32'd768;           // 768 = 10'b11_00000000 -> address[9:8] == 2'b11
                    readEnable  = 1'b1;
            
                    @(negedge clk);
                    readEnable  = 1'b0;
    
            #30;
            $finish;
        end
       
endmodule
