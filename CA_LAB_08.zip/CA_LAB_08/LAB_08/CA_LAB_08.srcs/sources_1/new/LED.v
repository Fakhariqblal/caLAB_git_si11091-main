`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 01:13:36
// Design Name: 
// Module Name: LED
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module LEDOutputInterface(
    input clk,
    input rst,
    input [31:0] write_data,
    input LEDWrite,
    output reg [15:0] LEDs
);

    // Asynchronous reset clears LEDs to 0 immediately on startup
    always @(posedge clk or posedge rst) begin
        if (rst)
            LEDs <= 16'b0;
        else if (LEDWrite)
            LEDs <= write_data[15:0]; // Slice lower 16 bits for physical LEDs
    end

endmodule