`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 11:04:05
// Design Name: 
// Module Name: TOP_2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module MemorySystemTop_FPGA (
    input clk,
    input btnC,                  // Reset
    input btnU,                  // Up Button: Trigger Write (pulse)
    input btnD,                  // Down Button: Hold to Read and View Data
    input [15:0] sw,             // 16 Onboard Switches
    output [15:0] led            // 16 Onboard LEDs
);

    // Pulse generator for write button (btnU)
    reg btnU_d, btnU_pulse;
    always @(posedge clk) begin
        btnU_d     <= btnU;
        btnU_pulse <= btnU && !btnU_d;
    end

    // Direct read enable: active whenever btnD is held down
    wire read_enable = btnD;

    // Internal 32-bit bus wiring
    wire [31:0] cpu_address    = {22'b0, sw[15:14], 8'b0};
    wire [31:0] cpu_write_data = {24'b0, sw[7:0]};
    wire [31:0] cpu_read_data;
    wire [15:0] core_leds;

    // Core Memory-Mapped System
    addressDecoderTop dut (
        .clk(clk),
        .rst(btnC),
        .address(cpu_address),
        .readEnable(read_enable),
        .writeEnable(btnU_pulse),
        .writeData(cpu_write_data),
        .switches(sw),
        .readData(cpu_read_data),
        .leds(core_leds)
    );

    // Physical LED Multiplexer:
    // - While holding btnD: Displays the internal readData on the LEDs
    // - Normal operation: Displays the LED peripheral output
    assign led = btnD ? cpu_read_data[15:0] : core_leds;

endmodule