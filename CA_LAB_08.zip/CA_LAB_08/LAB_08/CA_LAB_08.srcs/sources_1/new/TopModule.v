`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 01:16:16
// Design Name: 
// Module Name: TopModule
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// ============================================================================
// 5. Top Module: addressDecoderTop (matches Lab 8 specification)
// ============================================================================
module addressDecoderTop(
    input clk,
    input rst,
    input [31:0] address,
    input readEnable,
    input writeEnable,
    input [31:0] writeData,
    input [15:0] switches,
    output reg [31:0] readData,
    output [15:0] leds
);
    wire DataMemWrite;
    wire DataMemRead;
    wire LEDWrite;
    wire SwitchReadEnable;
    wire [31:0] DataMemReadData;
    wire [31:0] SwitchReadData;

    // Address Decoder Instance
    addressdecoder decoder(
        .address(address),
        .memwrite(writeEnable),
        .memread(readEnable),
        .DataMemWrite(DataMemWrite),
        .DataMemRead(DataMemRead),
        .LEDWrite(LEDWrite),
        .SwitchReadEnable(SwitchReadEnable)
    );

    // Data Memory Instance
    datamemory data_memory(
        .clk(clk),
        .address(address),
        .writedata(writeData),
        .memwrite(DataMemWrite),
        .readdata(DataMemReadData)
    );

    // LED Interface Instance
    LEDOutputInterface led_interface(
        .clk(clk),
        .rst(rst),
        .write_data(writeData[15:0]),
        .LEDWrite(LEDWrite),
        .LEDs(leds)
    );

    // Switch Interface Instance
    SwitchInputInterface switch_interface(
        .Switches(switches),
        .SwitchReadEnable(SwitchReadEnable),
        .read_data(SwitchReadData)
    );

    // Read Data Multiplexer
    always @(*) begin
        if (DataMemRead)
            readData = DataMemReadData;
        else if (SwitchReadEnable)
            readData = SwitchReadData;
        else
            readData = 32'b0;
    end

endmodule