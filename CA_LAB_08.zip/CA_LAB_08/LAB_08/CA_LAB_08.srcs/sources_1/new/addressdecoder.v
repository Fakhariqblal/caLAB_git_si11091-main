`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 01:12:18
// Design Name: 
// Module Name: addressdecoder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module addressdecoder(
    input  [31:0] address,
    input         memwrite,
    input         memread,
    output reg    DataMemWrite,
    output reg    DataMemRead,
    output reg    LEDWrite,
    output reg    SwitchReadEnable
);

    always @(*) begin
        // Explicit default assignments to avoid unwanted latches
        DataMemWrite     = 1'b0;
        DataMemRead      = 1'b0;
        LEDWrite         = 1'b0;
        SwitchReadEnable = 1'b0;


        case (address[9:8])
            2'b00: begin 
                DataMemWrite = memwrite;
                DataMemRead  = memread;
            end

            2'b01: begin 
                LEDWrite = memwrite;
            end

            2'b10: begin 
                SwitchReadEnable = memread;
            end

            default: begin
                
                DataMemWrite     = 1'b0;
                DataMemRead      = 1'b0;
                LEDWrite         = 1'b0;
                SwitchReadEnable = 1'b0;
            end
        endcase
    end

endmodule