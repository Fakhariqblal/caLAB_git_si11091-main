`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 20.10.2026 23:26:07
// Design Name: 
// Module Name: datamemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module datamemory(
    input clk,
    input [31:0] address,
    input [31:0] writedata,
    input memwrite,
    output [31:0] readdata
);

    // 512 x 32-bit data memory array
    reg [31:0] mem [0:511];
    integer i;

    // Initialize all memory words to zero to avoid unknown 'X' in simulation
    initial begin
        for (i = 0; i < 512; i = i + 1) begin
            mem[i] = 32'b0;
        end
    end

    // Synchronous write on positive clock edge
    always @(posedge clk) begin
        if (memwrite) begin
            mem[address[8:0]] <= writedata;
        end
    end

    // Asynchronous/combinational read for single-cycle RISC-V processor
    assign readdata = mem[address[8:0]];

endmodule