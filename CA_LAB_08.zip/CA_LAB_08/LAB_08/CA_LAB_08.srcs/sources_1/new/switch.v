`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 01:15:24
// Design Name: 
// Module Name: switch
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module SwitchInputInterface(
    input  [15:0] Switches,
    input         SwitchReadEnable,
    output [31:0] read_data
);

    // Zero-extend 16-bit switches to 32 bits when read enable is active
    assign read_data = SwitchReadEnable ? {16'b0, Switches} : 32'b0;

endmodule